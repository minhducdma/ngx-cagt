CKEDITOR.plugins.setLang( 'html5audio', 'el', {
    button: 'Προσθέστε HTML5 ήχο',
    title: 'HTML5 ήχος',
    infoLabel: 'Πληροφορίες ήχου',
    urlMissing: 'Η πηγή URL ήχου απουσιάζει.',
    audioProperties: 'Ιδιότητες ήχου',
    upload: 'Upload',
    btnUpload: 'Αποστολή στον διακομιστή',
    advanced: 'Προχωρημένα',
    autoplay: 'Αυτόματη αναπαραγωγή;',
    allowdownload: 'Επιτρέψτε τη λήψη;',
    advisorytitle: 'Advisory title',
    yes: 'Ναι',
    no: 'Όχι'
} );
